# mypackage
This library was acreated as an exmaple of hoe to publish your own python package
